import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators} from '@angular/forms';
import {MatDialog} from '@angular/material/dialog';
import { DialogComponent } from '../dialog/dialog.component';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  isSubmitted = false;
  toppings = new FormControl('');
  toppingList: string[] = ['Extra cheese', 'Mushroom', 'Onion', 'Pepperoni', 'Sausage', 'Tomato'];
  dialog1:any[]=[];
  data1: any = {
    name: '',
    email: '',
    multipleOption: ''  }
  constructor(public dialog: MatDialog) { }
  
  ngOnInit(): void {
  }



  registerForm = new FormGroup({
    name: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    multipleOption: new FormControl('',Validators.required),
  })

  get name(){
    return this.registerForm.get('name');
  }

  get email(){
    return this.registerForm.get('email');
  }

  get multipleOption(){
    return this.registerForm.get('multipleOption');
    
  }

  openDialog(): void {
    if(this.registerForm.valid){
      const dialogRef = this.dialog.open(DialogComponent, {
     
      });
      let data1= {name: this.registerForm.value.name,
                 email: this.registerForm.value.email,
                 multipleOption: this.registerForm.value.multipleOption}
  
  
      
                 console.log(data1);
                 
      
      
      
      localStorage.setItem('registrationdata', JSON.stringify(data1))
  
      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed');
        // this.animal = result;
      });
    }
    
  }

}
